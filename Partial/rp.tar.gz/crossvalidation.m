function [acertos erros] = crossvalidation()
    

    acertos =0;
    erros = 0;
    for p=1:10
        p
        [x1 x2 u1 u2] = normaliza(p);
        c1 = cov(x1);
        c2 = cov(x2);
        [l1 c] = size(x1);
        [l2 c] = size(x2);
        for i=1:170

            if(i<=70)
                imname = (p-1)*70 + i;
                classe = 'coleoptero';
                input = ['coleoptero/coleoptero'];
            else
                imname = (p-1)*100+(i-70);
                classe = 'lagarta';
                input = ['lagarta/lagarta'];
            end
            input = [input int2str(imname) '.bmp'];

            img =imread(input);

            resposta = discfunction(img, c1, c2, l1, l2, u1, u2);

            if(strcmp(classe,resposta))
                acertos = acertos +1;
            else
                erros = erros +1;
            end
            imname
            acertos
            erros
        end
    end
    arq = fopen('results.txt','w');
    fprintf(arq,'erros: %d\n',erros);
    fprintf(arq,'acertos: %d\n',acertos);
    fclose(arq);
end