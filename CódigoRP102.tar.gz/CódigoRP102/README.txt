Para Executar teste rode em seu Matlab o script testes.m

